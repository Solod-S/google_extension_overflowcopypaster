StackExchange.helpers.showToast("Successfuly saved", {
  type: "success",
  transientTimeout: 2000,
});
