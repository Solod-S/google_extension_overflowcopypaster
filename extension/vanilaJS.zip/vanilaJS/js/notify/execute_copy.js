StackExchange.helpers.showToast("Successfuly copied", {
  type: "success",
  transientTimeout: 2000,
});
