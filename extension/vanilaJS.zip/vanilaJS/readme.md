# Понадобится
- Chrome
- Firefox
- VS Code
- nodejs (14+)
- Опционально: Safari и XCode

# Полезные ссылки
- [API Chrome](https://developer.chrome.com/docs/extensions/reference/)
- [API Web Extensions MDN](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions)